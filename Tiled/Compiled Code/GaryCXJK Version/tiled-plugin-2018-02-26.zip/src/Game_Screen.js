
Game_Screen.prototype.startFlashForHeal = function() {
    this.startFlash([128, 192, 255, 128], 8);
};
