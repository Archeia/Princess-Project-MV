# Introduction

 * Tired of RPG Maker MV's Map Editor?
 * Do you want to map the XP way but more?
 * Tired of Parallax Mapping?
 * Want to do round corners?
 * Want to create a map with basically unlimited layers?

Well, now all those worries are gone! Instead, let's just use the awesome
map editor, Tiled! Free, easy to use and very flexible Map Editor. This is
one of our reveals for RMMV's release but due to unforeseen circumstances,
we were unable to showcase this really awesome plugin in RPG Maker Channel.

-- Archeia and Dr. Yami

Tiled is a separate application developed by Bjorn, and you can find it
here:

http://www.mapeditor.org/

