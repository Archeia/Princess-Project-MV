module CXJ
  module EXAMPLE
    CONST_EX = "This is a module."
	print "Current module: ", self, "\n"
  end
end